from unicodedata import normalize
import requests
from bs4 import BeautifulSoup
import pandas as pd # Импортируем нужные библиотеки

all_data = {} # Словарик для всех данных
for k in range(1, 99): # Перебираем страницы на auto.ru
    url = f'https://auto.ru/cars/all/?page={k}'  # Получившийся юрл
    response = requests.get(url) # Запрашиваем данные
    response.encoding = 'utf8'
    soup = BeautifulSoup(response.text, 'lxml') # Составляем супчик
    for i in soup.find_all('div', class_ = 'ListingItem'):  # Ищем блоки с данными по автомобилям
        name = i.h3.text  # Название ищется легко
        url2 = i.find('h3').a.get('href') # Ссылка на страницу
        try: # если страница не 404
            responsex = requests.get(url2)  # Запрашиваем данные со страницы
            responsex.encoding = 'utf8'  # Кодировка для полученных данных
            soupx = BeautifulSoup(responsex.text, 'lxml') # получаем суп
            namex = soupx.find('h1', class_='CardHead__title').text # название
            pricex = soupx.find('span', class_='OfferPriceCaption PriceUsedOffer__caption').text.replace(' ', '').replace('от', '').replace('₽', '')  # цена
            ranngex = soupx.find('li', class_='CardInfoRow CardInfoRow_kmAge').text[6::].replace(' ', '').replace('км', '') # пробег
            body_typex = soupx.find('li', class_='CardInfoRow CardInfoRow_bodytype').text[5::] # тип кузова
            colourx = soupx.find('li', class_='CardInfoRow CardInfoRow_color').text[4::] # цвет
            volumex, powerx, fuel_typex = map(str, soupx.find('li', class_='CardInfoRow CardInfoRow_engine').text[9::].split(' / ')) # тут все про двигатель: объем, мощность и топливо
            volumex = volumex.replace(' ', '').replace('л', '') # убираем буквы из объема и мощности
            powerx = powerx.replace(' ', '').replace('л.с.', '').replace('кВт', '')
            engine_boxx = soupx.find('li', class_='CardInfoRow CardInfoRow_transmission').text[7::] # тип коробюки передач
            drive_unitx = soupx.find('li', class_='CardInfoRow CardInfoRow_drive').text[6::] # привод
            datax = [namex, engine_boxx, body_typex, drive_unitx, colourx, volumex, powerx, fuel_typex, pricex, ranngex] # составляем итоговый список
        except BaseException: # иначе данных нет
            datax = [None, None, None, None, None, None, None, None, None, None]
        data = [j.text for j in i.find_all('div', class_ = 'ListingItemTechSummaryDesktop__cell')[0:5]]  # Данные в отедьном блоке (там коробка передач, тип кузова, привод, хар-ки двигателя
        for j in range(len(data)):  # В этом цикле мы нормализуем данные, полученные ранее, потому что там были всякие ненужные символы
            data[j] = normalize('NFKD', data[j]) # Сам процесс нормализации
        for j in data[0].split(' / '):  # В первом наборе данных одновременно есть объем двигателя, мощность и тип топлива, поэтому их надо разделить
            data.append(j) # Ну и потом добавляем в конец списка
        if data[-1] == 'Электро': # Но если у нас электрокар, то мы его не добавляем, он нам не нужен
            continue
        price = normalize('NFKD', i.find_all('div', class_='ListingItemPrice__content')[0].text).replace(' ', '').replace('от', '').replace('₽', '')  # Также добавляем цену, нормализованную и только цифры, потому что пробелы и значок рубля нам не нужен

        dist = normalize('NFKD', i.find_all('div', class_='ListingItem__kmAge')[0].text).replace(' ', '').replace('км', '')# То же самое с пробегом
        try:
            x = int(dist)
        except BaseException:
            continue
        data.append(price)  # Добавляем цену и пробег в список
        data.append(dist)
        data = data[1::]  # Убираем первый набор даннных, потому что мы его раскрыли в строке 19
        data[4] = data[4].replace(' ', '').replace('л', '')  # Также убираем ненужные знаки из объема двигателя
        data[5] = data[5].replace(' ', '').replace('л.с.', '').replace('.с.', '').replace('кВт', '') # И мощности
        data.insert(0, name)  # добавляем название машины сначала
        result = [] # список который долден получиться в итоге
        for i in range(1, len(data)): # проходимся по спискам и сравниваем, если совпадает, то нормально
            if data[i] != datax[i]: # если не совпадает (то есть страница 404), то берем с карточки
                result.append(data[i])
            else: # иначе берем со странички
                result.append(datax[i])
        print(name, result) # печатаем что получилось (необязательно)
        all_data[name] = result  #Добавляем в наш словарик данные

df = pd.DataFrame([[i, all_data[i][0], all_data[i][1], all_data[i][2], all_data[i][3], all_data[i][4], all_data[i][5], all_data[i][6], all_data[i][7], all_data[i][8]] for i in all_data], columns=['Машина', 'Тип коробки передач', 'Тип машины', 'Привод', 'Цвет', 'Объем двигателя (л.)', 'Мощность двигателя (л.с.)', 'Тип топлива', 'Цена (р.)', 'Пробег (км.)'])  # Создаем датафрейм из наших данных и необходимых полей
print(df)  # Выводим для проверки
df.to_csv('file.csv')  # Сохраняем в файлик